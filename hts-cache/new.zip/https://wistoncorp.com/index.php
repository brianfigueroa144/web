
<!DOCTYPE html>
<html lang="en">


<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:url" content="" />
    <meta property="og:type" content="" />
    <meta property="og:title" content="" />
    <meta property="og:description" content="" />
    <meta property="og:image" content="" />
    
    <!-- Title -->
    <title>wistoncorp</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/images/wisclogo.png">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700" rel="stylesheet">


    <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!-- Flaticon Css -->
    <link rel="stylesheet" href="assets/css/flaticon.css">

    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Animate Css -->
    <link rel="stylesheet" href="assets/css/animate.min.css">

    <!-- Magnific Popup Css -->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!-- Owl Carousel Css -->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

    <!-- Slicknav Css -->
    <link rel="stylesheet" href="assets/css/slicknav.min.css">

    <!-- Main Style -->
    <link rel="stylesheet" href="stylex.css">
    

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
</script>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = '276b891a3abd15e3062dfbaf1a19277eb8fafa53';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>
<noscript> Powered by <a href=“https://www.smartsupp.com” target=“_blank”>Smartsupp</a></noscript>



<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</head>
    
<body>

         <!-- Preloader -->
  <div class="loadingpage">
	<div class="counter">
        <div id="status"> </div>
	</div>
</div>
 
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>


    <!-- Site Wrapper-->
    <div class="site header-style-1">
        
        <!-- Header Area -->
        <header class="site-header">
            <div class="header-top-area">
                <div class="container">
                    <div class="row">
                        <div >
                            <div class="header-top-left no-list-style">
                                <ul>
                                    <li><div id="google_translate_element" style="float: left;margin-bottom: -90px !important;"></div></li>
                                </ul>
                            </div>
                        </div>

                        <!--<div >
                            <div class="header-top-right">
                                <div class="social-icons no-list-style" style="float: right;">
                                    <ul>
                                          <li><a class="facebook" href="https://t.me/CAPITALGAINTRADERS" target="_blank"><i class="fa fa-telegram"></i></a></li>
                                <li><a class="facebook" href="https://twitter.com/GainGaintraders" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                        <li><a class="instagram" href="https://www.instagram.com/capitalgaintraders?igsh=MW9md21kNm83MTZ0ZA==" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>

            <div class="header-middle-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-3">
                            <div class="site-branding">
                                <div class="logo-wrap">
                                    <a href="?a=home">
                                        <img src="assets/images/wisclogo.png" alt="xzopro" style="height:60px">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-9">
                            <div class="middle-right-section no-list-style">
                                <ul>
                                    <li>
                                        <i class="flaticon-signs"></i>
                                        <span class="bold-text">15, Bedford Square, Fitzrovia</span>
                                        <span class="normal-text">London, WC1B 3JA, UK</span>
                                    </li>



                                    <li>
                                        <i class="flaticon-time"></i>
                                        <span class="bold-text">Jan 1, 2015</span>
                                        <span class="normal-text">Project Start Date</span>
                                    </li>
                                    
                                    <li>
                                        <div id="google_translate_element"></div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="header-menu-area top-fixed-menu no-list-style">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                            <nav class="site-navigation navigation">
                                <ul id="primary-menu" class="menu">
                                    <li class="current-menu-item"><a href="?a=home">Home</a></li>
                                    <li><a href="?a=cust&page=about">About Us</a></li>
                                    <li><a href="?a=cust&page=plans">Investment Plans</a></li>
                                     <li><a href="?a=faq">Frequently asked questions</a></li>
                                     <li><a href="?a=support">contact Us</a></li>
                                                                                 <li><a href="?a=login">Access</a></li>
                                     <li><a href="?a=signup">Registration</a></li>
                                                                            
                                </ul>
                            </nav>
                        </div>


                    </div>
                </div>

                <!-- Mobile Menu -->
                <div class="mbl-menu-container">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div id="mobile-menu-wrap">
                                    <a href="?a=login" class="xzopro-btn slider-btn bordered-btn" style="float:right; margin-top:-45px">Investor Area</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Mobile Menu End-->
            </div>
        </header><!-- Header Area End -->

 


        <!-- Slider Area -->
        <div class="slider-main-wrapper slider-style-1">
            <div id="slider-wrapper" class="slider-wrapper owl-carousel">
                <!-- Single Slide Item -->
                <div class="single-slide-item slide-item-1 full-bg enable-overlay">
                    <div class="slide-content-wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-8 col-lg-9 offset-xl-0 offset-lg-0 col-md-10 col-12">
                                    <h1 class="slide-title" data-animation="fadeInUp" data-duration=".4s">Welcome to wistoncorp</h1>

                                    <h1 class="bold-title" data-animation="fadeInUp" data-duration=".4s" data-delay=".3s">A Name of Success</h1>

                                    <div data-animation="fadeInUp" data-duration=".4s" data-delay=".6s">
                                        <p>We provide best Investment service with 7 Years of experience.  It’s help you to generate more profit from us.</p>
                                    </div>
                                        <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=signup" class="xzopro-btn slider-btn fill-btn">Registration</a>
                                       <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=cust&page=about" class="xzopro-btn slider-btn bordered-btn">About Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Single Slide Item End-->

                <!-- Single Slide Item -->
                <div class="single-slide-item slide-item-2 full-bg enable-overlay">
                    <div class="slide-content-wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-8 col-lg-9 offset-xl-0 offset-lg-0 col-md-10 col-12">
                                    <h1 class="slide-title" data-animation="fadeInUp" data-duration=".4s">Generate real profit</h1>


                                    <h1 class="bold-title" data-animation="fadeInUp" data-duration=".4s" data-delay=".3s">With us!</h1>

                                    <div data-animation="fadeInUp" data-duration=".4s" data-delay=".6s">
                                        <p>We provide best Investment service with 7 Years of experience.  It’s help you to generate more profit from us.</p>
                                    </div>

                                    <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=signup" class="xzopro-btn slider-btn fill-btn">Registration</a>

                                    <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=login" class="xzopro-btn slider-btn bordered-btn">Access</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Single Slide Item End-->

                <!-- Single Slide Item -->
                <div class="single-slide-item slide-item-3 full-bg enable-overlay">
                    <div class="slide-content-wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-8 col-lg-9 offset-xl-0 offset-lg-0 col-md-10 col-12">
                                    <h1 class="slide-title" data-animation="fadeInUp" data-duration=".4s">Become A true partner</h1>


                                    <h1 class="bold-title" data-animation="fadeInUp" data-duration=".4s" data-delay=".3s">On investment market</h1>

                                    <div data-animation="fadeInUp" data-duration=".4s" data-delay=".6s">
                                        <p>We provide best Investment service with 7 Years of experience.  It’s help you to generate more profit from us.</p>
                                    </div>

                                    <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=signup" class="xzopro-btn slider-btn fill-btn">Registration</a>

                                    <a data-animation="fadeInUp" data-duration=".4s" data-delay=".9s" href="?a=cust&page=about" class="xzopro-btn slider-btn bordered-btn">About Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Single Slide Item End-->
            </div>
<section class="cta-area" style="background: #2f2e4e;">
 <script type="text/javascript" src="https://files.coinmarketcap.com/static/widget/coinMarquee.js"></script><div id="coinmarketcap-widget-marquee" coins="1,1027,825,5426,1839,2,1831" currency="USD" theme="dark" transparent="true" show-symbol-logo="true"></div>
  <center> <video width ="300" height="200" poster="assets/images/poster.jpg" controls autoplay>
<source src="capitalgaintraders.mp4" type="video/mp4 ">
</video></center> 
      
      
      
  <div class="footer-top-area no-list-style">
                <div class="container">
                    <center> <h2 class="section-title"><font color="white">About us</font></h2><br></center>
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="border-image-wrap">
                            <div class="border-image-wrap-border"></div>
                            <img src="assets/images/slidess.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="twbi-text">
                           <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
                            
                            
                          <h2 class="section-title"><font color="white">Profitable Trading and Investment Company</font></h2></div>
                            <font color="white"><b><p>wistoncorp is a British publicly traded multinational oil and gas company headquartered at wistoncorp is a public limited company with a primary listing on the London Stock Exchange (LSE) and secondary listings on Euronext Amsterdam. It is one of the oil and gas "supermajors" and by revenue and profits is one of the largest oil & Gas and utility company in the world, ranking within the top 10 of the Fortune global since 2014.<br><br>
 
We started as a local investment company situated in London, United Kingdom. Today we with expertise in blockchain development and finance, we are the fastest growing brand in the crypto investment market
We participants use forex to hedge against international currency and interest rate risk, to speculate on geopolitical events, and to diversify portfolios, among other reasons.<br><br>
However, we are clear moves by many in the non-governmental organization community to encourage more environmentally friendly and sustainable business practices in the mining gold industry.

                            </p></b></font>
                        </div>
                    </div>
                </div>
            
            <a href="?a=cust&page=about" class="xzopro-btn slider-btn fill-btn">Read More About Us</a>
            
              </div>
</div>    
      
     
     
     
     
     
     
     
     
   <section class="cta-area" style="background: #2f2e4e;">
             <section class="top-wrapper">
           
    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
                            
                            
                            <center><h2 class="section-title"><font color="white">WHY CHOOSE US?</font></h2></center>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <font size="3"><p>We remain true to the same principle on which our company was founded, providing superior services to our clients,putting their safety first,creating opportunities for our people.</p></font>
                            </div><br><br>
                            
            
            <section class="cta-area" style="background: #2f2e4e;">
            
             
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">

                      <center> <img class="_seg___img"  src="assets/images/fca.png" width="120" height="120"></center>
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>UK REGISTERED COMPANY</b></font></font></center></div> 
                          
                          <center><font size="4">FCA REF NO:</font><span class="blink"><font color="#0b6db8"><font size="3">650711</font></font></span></center>

                        <center><font size="4">COMPANY NO:</font><span class="blink"><font color="#0b6db8"><font size="3">145288944</font></font></span></center>
                        
                        <center><p><font color="white">Our Company is a legal financial company incorporated and headquartered in United Kingdom.Approved by Financial Conduct Authority(FCA)</font></p></center>
                        
                        
                       
                         <center> <a href="/assets/images/cert.png" class="xzopro-btn slider-btn fill-btn"><b>VERIFY CERTIFICATE</b></a> </center><br>
                          <center> <a href="/assets/images/coin.pdf" class="xzopro-btn slider-btn fill-btn"><b>HOW TO BUY COIN</b></a> </center><br>
                          
                          
                        
                       
                        
                        ______________________________________
                        
              </div>
                         <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/security.png" width="120" height="120"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>MAXIMUM SECURITY</b></font></font></center></div> 

                        
                       <center> <p>wistoncorp is on a secure server with protection from DDoS attacks. Also SSL Protection to protect our server and user data. Your investment is safe and your privacy is also protected.</p></center>
                        ______________________________________
                        
                    
                    </div>
                    <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/cus.png" width="120" height="120"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>24X7 SUPPORT SERVICE</b></font></font></center></div> 

                        
                       <center> <p>wistoncorp support work around the clock and ready to answer questions at 24/7. Our support team is always ready to answer the questions that you have. You can contact us any time.</p></center>
                        ______________________________________
                    
                    
                    
                </div>
                
                                    <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/easy.png" width="120" height="120"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>EASY TO USE</b></font></font></center></div> 

                        
                       <center> <p>If you are a beginner in the online investment field, you will find our platform very easy to operate. wistoncorp is  available worldwide</p></center>
                        ______________________________________
                    
                    
                    
                </div>
                <br> 
                <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/fast.png" width="120" height="120"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>FAST WITHDRAWAL</b></font></font></center></div> 

                        
                       <center> <p>All payment withdrawals are processed instantly! You can withdraw anytime. we process all transaction instantly</p></center>
                        ______________________________________
                    
                    
                    
                </div>
            </section>
        
    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
                            
                            
                            <center><h2 class="section-title"><font color="white">wistoncorp SERVICES</font></h2></center>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <font size="3"><p>We engage  in various online and offline businesses such as Real Estate management,oil and gas,Forex exchange market,gold mining and binary options  to generate massive profit for our clients</p></font>
                            </div><br><br>
                            
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">

                      <center> <img class="_seg___img"  src="assets/images/oil.png" width="150" height="150"></center>
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>OIL AND GAS INVESTMENT</b></font></font></center></div> 

                        
                        <center><p><font color="white">Oil and natural gas are major industries in the energy market and play an influential role in the global economy as the world's primary fuel sources. The processes and systems involved in producing and distributing oil and gas are highly complex, capital-intensive, and require state-of-the-art technology.</font></p></center>
                        
                        ______________________________________
                        
                    </div>
                         <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/f.png" width="150" height="150"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>FOREX EXCHANGE MARKET</b></font></font></center></div> 

                        
                       <center> <p>Foreign exchange market is a global decentralized or over-the-counter market for the trading of currencies. This market determines foreign exchange rates for every currency. It includes all aspects of buying, selling and exchanging currencies at current or determined prices.</p></center>
                        ______________________________________
                        
                    
                    </div>
                    <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/real.png" width="150" height="150"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>REAL ESTATE MANAGEMENT</b></font></font></center></div> 

                        
                       <center> <p>Real estate investing involves the purchase, management and sale or rental of real estate for profit. Improvement of realty property as part of a real estate investment strategy is generally considered to be a sub-specialty of real estate investing called real estate development.</p></center>
                        ______________________________________
                    
                    
                    
                </div>
                
                                    <br>           

                      <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/gold.png" width="150" height="150"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>GOLD MINING</b></font></font></center></div> 

                        
                       <center> <p>Gold mining is the extraction of gold resources by mining. Gold mining is a major economic driver for many countries across the world. Well-managed, transparent and accountable resource extraction can be a major contributor to economic growth due to the creation of employment and business opportunities for local people.</p></center>
                        ______________________________________
                    
                    
                    
                </div>
                <br> 
                <div class="col-lg-4 col-md-6">
                         
    
                           <center> <img class="_seg___img"  src="assets/images/binary.png" width="150" height="150"></center>
                                   
                        
                    <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 5px; margin: 0px; background-position: center;">
                            
                            
                          <center><font color="white"><font size="4"><b>BINARY OPTIONS</b></font></font></center></div> 

                        
                       <center> <p>Binary option is a financial exotic option in which the payoff is either some fixed monetary amount or nothing at all. The two main types of binary options are the cash-or-nothing binary option and the asset-or-nothing binary option. Our focus is to provide our affiliates with daily and constant profits in Binary optios markets.</p></center>
                        ______________________________________
                    
                    
                    
                </div>
            </div>
        </section>
          
        
        </section>  
     
     
     
     
     
     
      






</section>

            <div class="slider-promo-box-wrapper no-list-style">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="flaticon-arrows"></i>
                                        <h5>Profitable Plans</h5>
                                        <p>We provide best investment plans.</p>
                                    </a>
                                </li>

                                <li>
                                    <a href="#">
                                        <i class="flaticon-thinking"></i>
                                        <h5>Advanced Protection</h5>
                                        <p>Maximum protection against any attacks.</p>
                                    </a>
                                </li>

                                <li>
                                    <a href="#">
                                        <i class="flaticon-cogwheel-1"></i>
                                        <h5>Friendly Support</h5>
                                        <p>We provide Best support service.</p>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- Slider Area End -->

        <!-- Why Choose Us Area -->
        <section class="why-choose-us-wrapper section-padding">
            <!-- Section Title -->
            <div class="section-title-wrapper no-list-style">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                            <h2 class="section-title">Why Choose Us</h2>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <p>We have a team of professional and qualified financial analysts who are developing new strategies. We guaranteed your 100% satisfaction for investing with us!</p>
                        </div>
                    </div>
                </div>
            </div><!-- Section Title End-->

            <div class="container">
                <div class="row">
                    <div class="col-ld-12">
                        <div class="choose-us-container section-right-bg">
                            <div class="row">
                                <div class="col-lg-6 col-md-12">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-6">
                                            <!-- Single Choose Us Box -->
                                            <div class="single-choose-us-box">
                                                <div class="choose_us-content-wrapper">
                                                    <div class="choose-us-box-icon">
                                                        <i class="flaticon-rocket"></i>
                                                    </div>
                                                    <div class="choose_us-box-content">
                                                        <h4>Profitable Plans</h4>
                                                        <p>Our investment plans help you to generate maximum profits with minimum amount of investment. 100% possibility to increase your income easily with us.</p>
                                                    </div>
                                                </div>
                                            </div><!-- Single Choose Us Box End -->
                                        </div>

                                        <div class="col-lg-12 col-md-6">
                                            <!-- Single Choose Us Box -->
                                            <div class="single-choose-us-box">
                                                <div class="choose_us-content-wrapper">
                                                    <div class="choose-us-box-icon">
                                                        <i class="flaticon-analytics-1"></i>
                                                    </div>
                                                    <div class="choose_us-box-content">
                                                        <h4>Instant Payments</h4>
                                                        <p>Our all payment system is instant. If user request for withdrawal there profit then the profit added user account instantly. You can make as many requests as you want.</p>
                                                    </div>
                                                </div>
                                            </div><!-- Single Choose Us Box End -->
                                        </div>

                                        <div class="col-lg-12 col-md-6">
                                            <!-- Single Choose Us Box -->
                                            <div class="single-choose-us-box">
                                                <div class="choose_us-content-wrapper">
                                                    <div class="choose-us-box-icon">
                                                        <i class="flaticon-process"></i>
                                                    </div>
                                                    <div class="choose_us-box-content">
                                                        <h4>Strong Security</h4>
                                                        <p>Our site is on a secure server with protection from DDoS attacks. Also SSL Protection to protect our server and user data. Your investment is safe and your privacy is also protected. </p>
                                                    </div>
                                                </div>
                                            </div><!-- Single Choose Us Box End -->
                                        </div>

                                        <div class="col-lg-12 col-md-6">
                                            <!-- Single Choose Us Box -->
                                            <div class="single-choose-us-box">
                                                <div class="choose_us-content-wrapper">
                                                    <div class="choose-us-box-icon">
                                                        <i class="flaticon-cogwheel-1"></i>
                                                    </div>
                                                    <div class="choose_us-box-content">
                                                        <h4>24X7 Support Services</h4>
                                                        <p>We work around the clock and ready to answer questions at 24/7. Our support team is always ready to answer the questions that you have. You can contact us any time.</p>
                                                    </div>
                                                </div>
                                            </div><!-- Single Choose Us Box End -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- Why Choose Us Area End -->
        
        
        
         <!-- Counter Area -->
          
         <!-- Counter Area -->
       <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
                            
                           <center><h2 class="section-title"><font color="white">LIVE STATISTICS</font></h2></center></div>

        <!-- Footer Area -->
        <footer class="site-footer">
            <!-- Footer Top Area -->
            <div class="footer-top-area no-list-style">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-box-table ">
                            <div class="counter-box-cell">
                                <div class="single-counter-box">
                                    <div class="count-content">
                                        <div class="count-icon">
                                            <i class="flaticon-team"></i>
                                        </div>
                                        5M<span>+</span>
                                        <div class="count-text">Total Member</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                                            <div class="col-lg-3 col-md-6">
                        <div class="counter-box-table ">
                            <div class="counter-box-cell">
                                <div class="single-counter-box">
                                    <div class="count-content">
                                        <div class="count-icon">
                                            <i class="flaticon-rocket"></i>
                                        </div>
                                        <span>$</span>
                                        <div class="count-number">6528567519.01</div>
                                        <div class="count-text">Total Deposited</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="counter-box-table ">
                            <div class="counter-box-cell">
                                <div class="single-counter-box">
                                    <div class="count-content">
                                        <div class="count-icon">
                                            <i class="flaticon-coins"></i>
                                        </div>
                                        <span>$</span>
                              <div class="count-number"><span>7509362240.58</div>
                                        <div class="count-text">Total Withdraw</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    </div>

                    </div>
                    
                    <script type="text/javascript" src="https://files.coinmarketcap.com/static/widget/coinPriceBlock.js"></script> 

  <div id="coinmarketcap-widget-coin-price-block" coins="1,1027,825,825,4687,1831,5426,2,52" currency="USD" theme="dark" transparent="true" show-symbol-logo="true"></div>
    
       </div><!-- Counter Area End -->
       
       
       
        
        
        
   
<style>
.pricingTable{
    padding: 15px;
    margin: 20px 20px 30px;
    background: #0a6db7;
    border-radius: 50px;
    text-align: center;
    position: relative;
}

.pricingTable .pricingTable-header{
    padding: 50px 0;
    position: relative;
}

.pricingTable .title{
    padding: 10px 20px;
    background: #302e4e;
    font-size: 17px;
    font-weight: 600;
    color: #fff;
    letter-spacing: 1px;
    text-transform: uppercase;
    border-radius: 10px 10px 10px 0;
    position: absolute;
    top: 20px;
    left: -45px;
}

.pricingTable .title:before{
    content: "";
    border-top: 30px solid #4a4775;
    border-bottom: 30px solid transparent;
    border-left:30px solid transparent;
    position: absolute;
    bottom: -60px;
    left: 0;
}

.pricingTable .price-value{
    padding: 15px 30px;
    background: #302e4e;
    font-size: 40px;
    font-weight: 700;
    color: #ffffff;
    border-radius: 0 50px 50px 30px;
    position: absolute;
    top: -30px;
    right: -40px;
}

.pricingTable .price-value:before{
    content: "";
    position: absolute;
    top: 0;
    left: -36px;
    border-right: 20px solid #4a4775;
    border-top: 16px solid transparent;
    border-left: 16px solid transparent;
}

.pricingTable .pricing-content{
    padding: 0 0 15px 0;
    margin: 0;
    list-style: none;
    background: #fff;
    border-radius: 0 0 40px 40px;
}

.pricingTable .pricing-content li,
.pricingTable:hover .pricing-content li.disable,
.pricingTable.orange:hover .pricing-content li.disable,
.pricingTable.green:hover .pricing-content li.disable{
    padding: 0 0 0 25px;
    font-size: 15px;
    font-weight: 600;
    color: #9ea1a6;
    letter-spacing: 1px;
    /* line-height: 50px; */
    text-align: left;
    border-bottom: 2px solid #0a6db7;
    transition: all 0.3s ease 0s;
}

.pricingTable:hover .pricing-content li{ color: #0056b3; }

.pricingTable .pricing-content li i,
.pricingTable:hover .pricing-content li.disable i,
.pricingTable.orange:hover .pricing-content li.disable i,
.pricingTable.green:hover .pricing-content li.disable i{
    width: 25px;
    height: 25px;
    line-height: 22px;
    border-radius: 50%;
    border: 2px solid #302e4e;
    background: #0a6db7;
    text-align: center;
    font-size: 14px;
    color: #ffffff;
    margin-right: 10px;
    transition: all 0.3s ease 0s;
}

.pricingTable:hover .pricing-content li i{
    border: 2px solid #0a6db7;
    background: #302e4e;
    color: #fff;
}

.pricingTable .pricingTable-signup{
    width: 180px;
    height: 60px;
    line-height: 60px;
    background: #302e4e;
    border-radius: 30px 30px 30px 0;
    margin: 0 auto;
    font-size: 22px;
    font-weight: 700;
    color: #fff;
    text-transform: uppercase;
    position: absolute;
    bottom: -30px;
    left: 0;
    right: 0;
}

.pricingTable .pricingTable-signup:before{
    content: "";
    border-top: 30px solid #4a4775;
    border-bottom: 26px solid transparent;
    border-left: 22px solid transparent;
    position: absolute;
    bottom: -24px;
    left: -22px;
}

.pricingTable.orange{background: #302e4e;}

.pricingTable.orange .title,
.pricingTable.orange .price-value,
.pricingTable.orange .pricingTable-signup{background: #0a6db7;}

.pricingTable.orange .title:before,
.pricingTable.orange .pricingTable-signup:before{border-top-color: #1184da;}

.pricingTable.orange .price-value:before{border-right-color: #1184da;}

.pricingTable.orange .price-value,
.pricingTable.orange:hover .pricing-content li{/* color: #ffffff; */}

.pricingTable.orange .pricing-content li{border-bottom: 2px solid #302e4e;}

.pricingTable.orange:hover .pricing-content li i{
    border: 2px solid #0a6db7;
    background: #302e4e;
    color: #fff;
}

.pricingTable.green{background: #0a6db7;}

.pricingTable.green .title,
.pricingTable.green .price-value,
.pricingTable.green .pricingTable-signup{background: #302e4e;}

.pricingTable.green .title:before,
.pricingTable.green .pricingTable-signup:before{border-top-color: #4a4775;}

.pricingTable.green .price-value:before{border-right-color: #4a4775;}

.pricingTable.green .price-value,
.pricingTable.green:hover .pricing-content li{/* color: #ffffff; */}

.pricingTable.green .pricing-content li{border-bottom: 2px solid #0a6db7;}

.pricingTable.green:hover .pricing-content li i{
    border: 2px solid #0a6db7;
    background: #302e4e;
    color: #fff;
}

@media only screen and (max-width: 990px){
    .pricingTable{ margin-bottom: 50px; }
}

.pricing-table-wrapper i:before {
        font-size: unset;
}

.pricing-table-wrapper i {
    margin-bottom: 12px;
    margin-top: 8px;
}
</style>


        <!-- Pricing Area -->
<section class="procing-table-area section-padding">
            <!-- Section Title -->
            <div class="section-title-wrapper no-list-style">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                            <h2 class="section-title">Our Investment Plans</h2>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <p>We offer multiple Investment plans for our investors. You can choose any plan that you like best. Our all plans are profitable.</p>
                        </div>
                    </div>
                </div>
            </div><!-- Section Title End-->

            <!-- Pricing Table Wrapper -->
            <div class="pricing-table-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <!-- Single Pricing Table -->
                            <div class="single-pricing-table no-list-style">
                                <i class="flaticon-arrows"></i>
                                <h2>Basic Plan</h2>

                                <ul>
                                    <li>Minimum = $50</li>
                                    <li>Maximum = $300</li>
                                    <li>Profit = 5%</li>
                                    <li>Duration = 24 Hours</li>
                                    <li>Instant - Withdrawal</li>
                                    <li>24/7 Costomer Support</li>
                                </ul>

                                
                                <a href="?a=signup" class="xzopro-btn fill-btn pricing-btn">Invest Now</a>
                            </div><!-- Single Pricing Table End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Pricing Table -->
                            <div class="single-pricing-table no-list-style">
                                <div class="table-tag">Popular</div>
                                <i class="flaticon-arrows"></i>
                                <h2>Silver Plan</h2>

                                     <ul>
                                    <li>Minimum = $500</li>
                                    <li>Maximum = $1,200</li>
                                    <li>Profit = 10%</li>
                                    <li>Duration = 3 Days</li>
                                    <li>Instant - Withdrawal</li>
                                    <li>24/7 Costomer Support</li>
                                </ul>

                                <a href="?a=signup" class="xzopro-btn fill-btn pricing-btn">Invest Now</a>
                            </div><!-- Single Pricing Table End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Pricing Table -->
                            <div class="single-pricing-table no-list-style">
                                <i class="flaticon-arrows"></i>
                                <h2>Platinum Plan</h2>

                                     <ul>
                                    <li>Minimum = $3,600</li>
                                    <li>Maximum = $7,900</li>
                                    <li>Profit = 15%</li>
                                    <li>Duration = 5 Days</li>
                                    <li>Instant - Withdrawal</li>
                                    <li>24/7 Costomer Support</li> 
                                </ul>

                                
                                <a href="?a=signup" class="xzopro-btn fill-btn pricing-btn">Invest Now</a>
                            </div><!-- Single Pricing Table End -->
                        </div>
                        
                        
                        
                        <div class="col-lg-4 col-md-6">
                            <!-- Single Pricing Table -->
                            <div class="single-pricing-table no-list-style">
                                <i class="flaticon-arrows"></i>
                                <h2>Gold Plan</h2>

                                     <ul>
                                    <li>Minimum = $10,600</li>
                                    <li>Maximum = Unlimited</li>
                                    <li>Profit = 20%</li>
                                    <li>Duration = 7 Days</li>
                                    <li>Instant - Withdrawal</li>
                                    <li>24/7 Costomer Support</li> 
                                </ul>

                                
                                <a href="?a=signup" class="xzopro-btn fill-btn pricing-btn">Invest Now</a>
                            </div><!-- Single Pricing Table End -->
                        </div>
                        
                        
                        <div class="col-lg-4 col-md-6">
                            <!-- Single Pricing Table -->
                            <div class="single-pricing-table no-list-style">
                                <i class="flaticon-arrows"></i>
                                <h2>Loan Plan</h2>
                                <h2>Down Balance $200</h2>
                                     <ul>
                                    <li>Deposite up to $200 to get loan of</li>
                                    <li>$1,000 - $20,000</li>
                                    <li>24/7 Costomer Support</li> 
                                </ul>

                                
                                <a href="?a=signup" class="xzopro-btn fill-btn pricing-btn">Invest Now</a>
                            </div><!-- Single Pricing Table End -->
                        </div>
                        
                        
                    </div>
                </div>
            </div><!-- Pricing Table Wrapper End -->
        </section><!-- Pricing Area End -->
        
        
                <!-- Service Area -->
        <section class="home-1 service-section section-padding full-bg enable-overlay">
            <!-- Section Title -->
            <div class="section-title-wrapper no-list-style">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                            <h2 class="section-title">Our Services</h2>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <p>We provide best investment service with many features. Our experts give you benefit from total transparency to achieve control and make better decisions.</p>
                        </div>
                    </div>
                </div>
            </div><!-- Section Title End-->

            <!-- Service Box Wrapper -->
            <div class="service-box-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-analytics"></i>
                                    </div>
                                    <div class="service-box-content">
                                        <h4>Maximal Protection</h4>
                                        <p>We use dedicated server which protect our website from any DDoS attack. Also secured connection by SSL service.</p>
                                      
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-coding"></i>
                                    </div>
                                    <div class="service-box-content">
                                       <h4>Easy to use</h4>
                                        <p>If you are a beginner in the online investment field, that you will find our platform to use easily. Website available worldwide.</p>
                                        
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-analytics-1"></i>
                                    </div>
                                    <div class="service-box-content">
                                       <h4>Instant Payment</h4>
                                        <p>Our all payment withdrawals are processed instantly! You can withdraw anytime. we are process all transaction instantly.</p>
                                      
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-coins"></i>
                                    </div>
                                    <div class="service-box-content">
                                        <h4>High profitability</h4>
                                        <p>We offer the best strategy to generate maximum profits with minimum amount of your investment.</p>
                                      
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-thinking"></i>
                                    </div>
                                    <div class="service-box-content">
                                        <h4>Professional Team</h4>
                                        <p>Our experienced team of highly qualified financial experts and professional traders always available to generate more profit.</p>
                                     
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <!-- Single Service Box -->
                            <div class="single-service-box service-box-style-1">
                                <div class="service-content-wrapper">
                                    <div class="service-box-icon">
                                        <i class="flaticon-diamond"></i>
                                    </div>
                                    <div class="service-box-content">
                                       <h4>Unique platform</h4>
                                        <p>Our expert developers do everything for your convenience and safety to investing our platform safely.</p>
                                     
                                    </div>
                                </div>
                            </div><!-- Single Service Box End -->
                        </div>
                    </div>
                </div>
            </div><!-- Service Box Wrapper End -->
        </section><!-- Service Area End -->
        


<style>
.form-back{
    padding:25px;
    background: rgb(48, 46, 78);
    background-size:cover;

}

.wrap-formrequest{
    width: 100%;
}
 .form-back-inner{
    background:url(images/calculator.png) no-repeat left;

}
 .form-back-inner label{
    text-transform:uppercase;
    font-size:16px;
    display:block;
    color: #fff;
}
 .form-back-inner .form-control{
    background: #0a6db7;

    border-color:#484848;
    color:#fff;
    font-weight:700;
    height:50px;
    font-size:16px;
    text-transform:uppercase;
}
 .form-back-inner .amount{
     line-height:50px;
     font-weight:700;
     font-size:30px;
}
 .form-back-inner button{
    background:#ffc80a;
     border-radius:10px;
     border-color:#484848;
     color:#fff;
     font-weight:700;
     height:50px;
     font-size:18px;
     text-transform:uppercase;
     cursor:pointer;
     width:100%;
     text-align:center;
     border:none;
}
 .form-back-inner button span{
     background:url(../images/pig-icon.png) no-repeat left;
     line-height:34px;
     display:inline-block;
     padding-left:40px;
}
 .form-back-inner .form-group{
     margin-bottom:0;
}
 select.form-control:not([size]):not([multiple]) {
    height: 50px;
    padding: 12px 20px;
    margin: 8px 0;
}
</style>
        
       
  

<style>  
/** Stats style **/

table > tbody > tr > td:nth-child(1) {

    background: rgba(48, 46, 78, 0.30);
}

table > tbody > tr > td:nth-child(2) {background: rgba(10, 109, 183, 0.3);color: #fff;}

table > tbody > tr > td:nth-child(3) {background: rgba(48, 46, 78, 0.3);color: #fff;}

div.testimonial-main-wrap > div > div > div:nth-child(1) > h3 {
        color: #ffffff;
}
div.testimonial-main-wrap > div > div > div:nth-child(2) > h3 {
        color: #ffffff;
}

</style>  
 
 
 
 
 <section class="cta-area" style="background: #2f2e4e;">
 <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
    <center><h2 class="_seg____header__"><font color="white">Approved Payment Method</font></h2>
    <font color="white"><p>We Accept BITCOIN,ETHEREUM,USDT,PAYEER AND PERFECT MONEY payment method </p></font>
    </center></div>
    </section>
    <section class="cta-area" style="background: #2f2e4e;">
    
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="xzopro-client owl-carousel">
                            


                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="images/1000.gif" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="images/1001.gif" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="images/1002.gif" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="images/1003.gif" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="images/1004.gif" alt="">
                                </div>
                            </div>
                            
                            
                                                      
                        </div>
                    </div>
                </div>
            </div>
        </section>
    
    
    
    
    
    
 
 
 
 <section class="cta-area" style="
    background-image: url(modern_theme/build/img/header.jpg);
    text-align: center;
    /* padding: 100px 0; */
    background-position: center;
    background-size: cover;
    background-color: #0b6db8;
    margin-bottom: 50px;
">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4>We provide <span class="blink">4%</span> Referral commission</h4>
                        <p>Make your dream project with us and stay tensionfree.</p>
                    </div>

                    
                </div>
            </div>
        </section>
        
 <style>
 
     @-webkit-keyframes blinker {
  from {opacity: 1.0;}
  to {opacity: 0.0;}
}
.blink{
	color:#302e4e;
	font-size: 40px;
	text-decoration: blink;
	-webkit-animation-name: blinker;
	-webkit-animation-duration: 0.6s;
	-webkit-animation-iteration-count:infinite;
	-webkit-animation-timing-function:ease-in-out;
	-webkit-animation-direction: alternate;
}

 </style>
 
 
        
        
        
        
        
         <!-- Progressbar Area -->
        <section class="cta-area" style="background: #2f2e4e;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="twb-wrapper ">
                            
                            <div style="background: #0b6db8; width: 100%; display: block; overflow: hidden; float: left; padding: 10px; margin: 0px; background-position: center;">
                            
                           <center><h2 class="section-title"><font color="white">Many Years Of Experience</font></h2></center></div>
                            <div class="twb-content-text">
                                <p>wistoncorp is founded by a team of professional traders who know exactly what it takes to earn the most from capital market. Our company provides a full investment service focused on the Forex and cryptocurrency trading. Each trader in our group has more than 7 years of trading experience and successful trading records.</p>
                                <p>As we know that is the exact point that supports our company stability and profitability.
                                </p>
                            </div>

                            <div class="twb-btn">
                                <a href="?a=signup" class="xzopro-btn fill-btn">Signup now</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Forex trading</div>
                                <div class="skillbar" data-percent="98%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">95</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->


                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Oil and Gas</div>
                                <div class="skillbar" data-percent="100%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">100</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->
                        
                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Gold mining</div>
                                <div class="skillbar" data-percent="99%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">99</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->
                        
                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Real Estate Management</div>
                                <div class="skillbar" data-percent="95%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">95</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->
                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Cryptocurrency Trading</div>
                                <div class="skillbar" data-percent="99%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">99</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->

                        <!-- Single Progress Bar -->
                        <div class="progress-wrapper">
                            <div class="skill-wrapper">
                                <div class="skill-title">Binary options</div>
                                <div class="skillbar" data-percent="97%">
                                    <div class="progress-fill-bar">
                                        <div class="skill-percent-count-wrap"><span class="skill-percent-count">97</span>%</div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- Single Progress Bar End -->
                    </div>
                </div>
            </div>
        </section><!-- Progressbar Area End -->
        
        
        
        
        
        
        
        
        
        
        
                <!-- Testimonial Area -->
<section class="testimonial-area section-padding enable-overlay full-bg">
            <!-- Section Title -->
            <div class="section-title-wrapper no-list-style">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                            <h2 class="section-title">Our Business Stats</h2>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <p>Check our latest live deposit & withdrawals statistics. We are tried to give our best for all users. Our expert team always ready to help them.</p>
                        </div>
                    </div>
                </div>
            </div><!-- Section Title End-->

            <!-- Testimonial main wrapper -->
            <div class="testimonial-main-wrap">
                <div class="container">
                    <div class="row">
         <div class="col-md-6">
            <h3 class="text-uppercase line-bottom-double-line-centered mt-0" style="text-align: center;
               ">Latest <span class="text-theme-colored2">Deposit</span></h3>
            <table class="table table-bordered" style="text-align: center;">
              <tbody>
  
                    
                  </tbody>
            </table>
         </div>
         <div class="col-md-6">
            <h3 class="text-uppercase line-bottom-double-line-centered mt-0" style="text-align: center;
               ">Latest <span class="text-theme-colored2">Withdraw</span></h3>
            <table class="table table-bordered" style="text-align: center;">
               <tbody>
                   
</tbody>
            </table>
         </div>
      </div>
                </div>
            </div><!-- Testimonial main wrapper -->
        </section><!-- Testimonial Area End -->
        
        
                <!-- Client / Brand Logo Area -->
        <div class="client-logo-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="xzopro-client owl-carousel">
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p1.png" alt="">
                                </div>
                            </div>

                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p2.png" alt="">
                                </div>
                            </div>


                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p4.png" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p5.png" alt="">
                                </div>
                            </div>
                                                        <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p6.png" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p7.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- Client / Brand Logo Area End-->
        
        
         <div class="client-logo-area">
             
              <!-- Section Title -->
            <div class="section-title-wrapper no-list-style">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                            <h2 class="section-title">Client Testimony</h2>
                            <ul class="title-shape text-center">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <p>What our investors say about our company.</p>
                        </div>
                    </div>
                </div>
            </div><!-- Section Title End-->
             
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="xzopro-client owl-carousel">
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p1.png" alt="">
                                </div>
                            </div>

                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p2.png" alt="">
                                </div>
                            </div>


                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p4.png" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p5.png" alt="">
                                </div>
                            </div>
                                                        <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p6.png" alt="">
                                </div>
                            </div>
                            <div class="single-logo-box">
                                <div class="single-brand-logo">
                                    <img src="assets/images/p7.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- Client / Brand Logo Area End-->
        
        

<style>
    .xxx img{
   opacity: .5;
   filter: grayscale(80%);
   transition-duration: 1s;
   transition-timing-function: linear;
}
.xxx img:hover{
     opacity: .9;
    filter: grayscale(0%);
}

</style>
 
<section class="cta-area" style="
    background-size: cover;
    background-color: #ffffff;
    padding: 35px 0 35px;
">
            <div class="container">
                <div class="row">
                                
                                
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s1.png">
    </div></div>
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s2.png">
    </div></div>
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s3.png">
    </div></div>
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s4.png">
    </div></div>
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s5.png">
    </div></div>
<div class="col-lg-2">
    <div class="xxx">
    <img src="assets/images/s6.png">
    </div></div>
    </div>
     </div>
     </section>
        
        

<script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="styles/calc/jquery-2.js"></script>
<script type="text/javascript" src="styles/calc/calc.js"></script> 

        <!-- Footer Area -->
        <footer class="site-footer">
            <!-- Footer Top Area -->
            <div class="footer-top-area no-list-style">
                <div class="container">
                    <div class="row">
                        <!-- Footer widget 1 -->
                        <div class="widget col-lg-3 col-md-6">
                            <a class="footer-widget-logo" href="?a=home">
                                <img class="img-responsive" src="assets/images/wisclogo.png" alt="logo" style="height:60px">
                            </a>

                            <div class="footer-widget-about-description">
                                <p>wistoncorp is a very professional decision making tool which helps determine the terms and amount of each trade </p>
                                <p>and win up to 97% of trades with the total profit rate of up to 12% per day.</p>
                            </div>

                          <!--  <p>Follow us : </p>

                            <ul class="social-icons">
                                <li><a class="facebook" href="https://t.me/CAPITALGAINTRADERS" target="_blank"><i class="fa fa-telegram"></i></a></li>
                                <li><a class="facebook" href="https://twitter.com/GainGaintraders" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                        <li><a class="instagram" href="https://www.instagram.com/capitalgaintraders?igsh=MW9md21kNm83MTZ0ZA==" target="_blank"><i class="fa fa-instagram"></i></a></li>
                            </ul>-->
                        </div><!-- Footer widget 1 End -->

                        <!-- Footer widget 2 -->
                        <div class="widget col-lg-3 col-md-6 widget_nav_menu">
                            <h2 class="widget-title">Usefull link</h2>
                            <div class="menu-usefull-links-container navigation">
                                <ul id="menu-usefull-links" class="menu">
                                    <li><a href="?a=home">Home</a></li>
                                    <li><a href="?a=cust&page=about">About Us</a></li>
                                    <li><a href="?a=cust&page=plans">Plans</a></li>
                                    <li><a href="?a=faq">Faq</a></li>
                                    <li><a href="?a=rules">Privacy Policy</a></li>
                                    <li><a href="?a=support">Contact</a></li>
                                </ul>
                            </div>
                        </div><!-- Footer widget 2 End -->

                        <!-- Footer widget 3 -->
                        <div class="widget col-lg-3 col-md-6 widget_xzopro-latest-post">
                            <h2 class="widget-title"> Recent News</h2>
                            <ul class="recent-news-widget">
                              
                            </ul>
                        </div><!-- Footer widget 3 End -->

                        <!-- Footer widget 4 -->
                        <div class="widget col-lg-3 col-md-6">
                            <h2 class="widget-title">Contact Information</h2>
                            <ul class="address-widget-list">
                                <li class="footer-address-desc">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                    <p>15, Bedford Square, Fitzrovia, London, WC1B 3JA, UNITED KINGDOM</p>
                                </li>

                                <li class="footer-mail-address">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    <p><a href="#"><span class="__cf_email__" data-cfemail="88e0ede4f8ecedfbe3c8edf0f8fae7eae1fca6eae1f2">support@wistoncorp.com</span></a></p>
                                </li>

                                <li class="footer-mobile-number">
                                    <div id="google_translate_element"></div>
                                </li>
                            </ul>

                               <div class="footer-subscribe-form">
                             <img src="assets/images/pay.jpg" alt="">
                              </div>
                        </div><!-- Footer widget 4 End -->
                    </div>
                </div>
            </div><!-- Footer Top Area End -->


            <!-- Footer Bottom Area -->
            <div class="footer-bottom-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 order-lg-first order-last">
                            <div class="site-info">
                                &copy; wistoncorp.com 2019 | Developed by : <a target="_blank" href="#">wistoncorp</a>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-12">
                            <div class="footer-bottom-menu-container navigation">
                                <ul id="footer-bottom-menu" class="menu">
                                    <li><a href="?a=home">Home</a></li>
                                      <li><a href="?a=news">News</a></li>
                                    <li><a href="?a=rules">Privacy Policy</a></li>
                                    <li><a href="?a=support">Contact</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!-- Footer Bottom Area End -->
        </footer><!-- Footer Area End -->
    </div><!-- Site Wrapper End-->

    <!-- Jquery -->
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-1.12.4.min.js"></script>
    
  
    <!-- Pooper Js -->
    <script src="assets/js/popper.min.js"></script>

    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Owl Carousel Js -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Waypoint Js -->
    <script src="assets/js/waypoint.js"></script>

    <!-- Counterup Js -->
    <script src="assets/js/counterup.js"></script>

    <!-- Isotope Js -->
    <script src="assets/js/isotope.min.js"></script>

    <!-- Appear Js -->
    <script src="assets/js/jquery.appear.js"></script>

    <!-- Magnific Popup Js -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!-- Sticky Js -->
    <script src="assets/js/sticky.js"></script>

    <!-- Slicknav Js -->
    <script src="assets/js/slicknav.min.js"></script>

    <!-- Template Custom Js -->
    <script src="assets/js/active.js"></script>
    
    <!-- Template Custom Js -->
    <script src="assets/js/load.js"></script>
    


</body>
</html> 